# oibsip_taskno-01
Java Development Internship - OASIS INFOBYTE
Welcome to Oasis Infobyte Java Development Projects repository. 
This repository contains Java projects, including "Online Examination System, Number Guessing Game and ATM Interface ." T
hese projects are designed to help you improve your Java programming skills and showcase your knowledge.

Project 1: Online Examination System
The first project I worked on was an online examination system. 
This project allowed me to explore the world of web development and learn how to create a user-friendly interface for an online exam. 
I was able to implement features such as user authentication, a timer for the exam, and automatic submission of answers.
I also learned how to use Java technologies such as Servlets and JSPs to create dynamic web pages.
